import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.InputMismatchException;
import java.util.Scanner;

public class DataStoreHelper 
{
	public void addEmployee(Employee e1) throws ClassNotFoundException, SQLException, IOException
	{
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data","root", "shubhamdarda");
		Statement st = con.createStatement();
		st.executeUpdate("INSERT INTO EMPLOYEES VALUES('"+Employee.empid+"','"+Employee.fname+"','"+Employee.lname+"','"+Employee.mob+"','"+Employee.designation+"','"+Employee.salary+"','"+Employee.city+"')");
		System.out.println("\nValues Inserted Successfully");
	}
	
	public void viewEmployee(String empid) throws ClassNotFoundException, IOException
	{
		System.out.println("________________________________");
		try
		{
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data","root", "shubhamdarda");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM EMPLOYEES WHERE EMPID='"+empid+"'");
			rs.next();
			System.out.println(rs.getString(2)+"'s Information");
			System.out.println("________________________________");
			System.out.println("EMPID: "+rs.getString(1)+"\nFirst Name: "+rs.getString(2)+"\nLast Name: "+rs.getString(3)+"\nMobile No.: "+rs.getString(4)+"\nDesignation: "+rs.getString(5)+"\nCurrent Salary: "+rs.getDouble(6)+"\nCity: "+rs.getString(7));
		}
		catch(SQLException e)
		{
			System.out.println("Record Not Found");
		}
		System.out.println("________________________________\n");
	}
	
	public void viewAllEmployee(String empid) throws ClassNotFoundException, IOException
	{
		int count=0;
		try
		{
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data","root", "shubhamdarda");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM EMPLOYEES");
			System.out.println("________________________________");
			while(rs.next())
			{
				System.out.println("EMPID: "+rs.getString(1)+"\nFirst Name: "+rs.getString(2)+"\nLast Name: "+rs.getString(3)+"\nMobile No.: "+rs.getString(4)+"\nDesignation: "+rs.getString(5)+"\nCurrent Salary: "+rs.getDouble(6)+"\nCity: "+rs.getString(7));
				System.out.println("________________________________");
				count++;
			}
			System.out.println("Total Number of Records "+count);
		}
		catch(SQLException e)
		{
			System.out.println("Database is Empty");
		}
	}
	public void removeEmployee(String empid) throws ClassNotFoundException, SQLException, IOException 
	{
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data","root", "shubhamdarda");
		Statement st = con.createStatement();
		st.executeUpdate("DELETE FROM EMPLOYEES WHERE EMPID='"+empid+"'");
		System.out.println("Employee Removed Successfully");
	}

	public void updateEmployee(String empid) throws ClassNotFoundException, SQLException, IOException 
	{
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data","root", "shubhamdarda");
		Statement st = con.createStatement();
		Scanner sc = new Scanner(System.in);
		int ch;
		try
		{
			System.out.println("________________________________");
			System.out.println("Update Your Information");
			System.out.println("________________________________");
			System.out.println("1. Mobile Number\n2. Designation\n3. City");
			System.out.println("________________________________");
			System.out.print("Enter Your Choice ");
			ch = sc.nextInt();
			switch(ch)
			{
			case 1:
				String mob = Employee.mobile();
				st.executeUpdate("UPDATE EMPLOYEES SET MOB='"+mob+"' WHERE EMPID='"+empid+"'");
				break;
			case 2:
				String designation = Employee.select_desig();
				st.executeUpdate("UPDATE EMPLOYEES SET DESIGNATION='"+designation+"' WHERE EMPID='"+empid+"'");
				break;
			case 3:
				String city = Employee.city();
				st.executeUpdate("UPDATE EMPLOYEES SET CITY='"+city+"' WHERE EMPID='"+empid+"'");
				break;
			default:
				System.out.println("\nWrong Choice Entered... Please Try Again");	
			}
		}
		catch(InputMismatchException ime)
		{
			System.out.println("\nWrong Choice Entered... Please Try Again");
			Employee.select_desig();
		}
		System.out.println("Record Updated Successfully");
	}
	
	public void updateEmployeeDesig(String empid, String designation) throws ClassNotFoundException, SQLException, IOException 
	{
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data","root", "shubhamdarda");
		con.createStatement();
		System.out.println("Record Updated Successfully");
	}

	public void dropAllEmployee() throws SQLException 
	{
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data","root", "shubhamdarda");
		Statement st = con.createStatement();
		st.executeUpdate("DROP TABLE EMPLOYEES");
		System.out.println("All Employees Removed Successfully");
	}
}
