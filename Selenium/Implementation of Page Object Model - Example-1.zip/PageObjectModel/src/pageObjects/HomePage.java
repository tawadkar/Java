package pageObjects;

import org.openqa.selenium.*;

public class HomePage 
{
	static String actualTitle, expectedTitle;
	static WebElement logout = null;
	
	public static String title(WebDriver driver)
	{
		actualTitle = driver.getTitle();
		expectedTitle = "Welcome: Mercury Tours";
		if(actualTitle.equalsIgnoreCase(expectedTitle))
		{
			System.out.println("Page Title Matched");
		}
		else
		{
			System.out.println("Page Title Not Matched");
		}
		return actualTitle;
	}
	
	public static WebElement logout(WebDriver driver)
	{
		logout = driver.findElement(By.id("account_logout"));
		return logout;
	}
}