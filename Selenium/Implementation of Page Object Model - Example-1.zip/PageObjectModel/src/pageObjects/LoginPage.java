package pageObjects;

import org.openqa.selenium.*;

public class LoginPage 
{
	private static WebElement element = null;
	public static WebElement username(WebDriver driver) 
	{
		element = driver.findElement(By.name("userName"));
		return element;
	}
	
	public static WebElement password(WebDriver driver) 
	{
		element = driver.findElement(By.name("password"));
		return element;
	}
	
	public static WebElement login(WebDriver driver) 
	{
		element = driver.findElement(By.name("login"));
		return element;
	}
	
	public static WebElement logout(WebDriver driver) 
	{
		element = driver.findElement(By.xpath("//*[@class='mouseOut']//*[text()='SIGN-OFF']"));
		return element;
	}
}
