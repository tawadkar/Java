package test;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pageObjects.HomePage;
import pageObjects.LoginPage;

public class TestCase 
{
	private static WebDriver driver = null;
	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver", "D://Selenium//Drivers//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://newtours.demoaut.com/");
		
		System.out.println("Actual Title - "+HomePage.title(driver));
		LoginPage.username(driver).sendKeys("mercury");
		LoginPage.password(driver).sendKeys("mercury");
		LoginPage.login(driver).click();
		LoginPage.logout(driver).click();
		System.out.println("Sign-Off Successfully");
		driver.quit();
	}
}





