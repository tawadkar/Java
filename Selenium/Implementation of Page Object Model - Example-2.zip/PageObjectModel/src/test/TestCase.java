package test;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pageObjects.HomePage;
import pageObjects.LoginPage;

public class TestCase 
{
	static WebDriver driver;
	static LoginPage lp;
	static HomePage hp;

	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver", "D://Selenium//Drivers//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://newtours.demoaut.com/");

		lp = new LoginPage(driver);
		hp = new HomePage(driver);
		lp.login("mercury", "mercury");
		hp.title();
		lp.logout();
		System.out.println("Sign-Off Successfully");
		driver.close();
	}
}



