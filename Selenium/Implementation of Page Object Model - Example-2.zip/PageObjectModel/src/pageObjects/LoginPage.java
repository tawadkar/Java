package pageObjects;

import org.openqa.selenium.*;

public class LoginPage 
{
	WebDriver driver;
	By username = By.name("userName");
	By password = By.name("password");
	By login = By.name("login");

	public LoginPage(WebDriver driver) 
	{
		this.driver = driver;
	}

	public void sendUsername(String strUserName) 
	{
		driver.findElement(username).sendKeys(strUserName);
	}

	public void sendPassword(String strPassword) 
	{
		driver.findElement(password).sendKeys(strPassword);
	}

	public void clickLogin() 
	{
		driver.findElement(login).click();
	}

	public void logout() 
	{
		driver.findElement(By.xpath("//*[@class='mouseOut']//*[text()='SIGN-OFF']")).click();
	}

	public void login(String strUserName, String strPasword) 
	{
		this.sendUsername(strUserName);
		this.sendPassword(strPasword);
		this.clickLogin();
	}
}
