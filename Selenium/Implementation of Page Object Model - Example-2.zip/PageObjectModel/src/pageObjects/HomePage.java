package pageObjects;

import org.openqa.selenium.*;

public class HomePage 
{
	WebDriver driver;

	public HomePage(WebDriver driver) 
	{
		this.driver = driver;
	}

	public void title() 
	{
		String actualTitle, expectedTitle;
		actualTitle = driver.getTitle();
		expectedTitle = "Welcome: Mercury Tours";
		if (actualTitle.equalsIgnoreCase(expectedTitle)) 
		{
			System.out.println("Page Title Matched");
		} 
		else 
		{
			System.out.println("Page Title Not Matched");
		}
	}
}